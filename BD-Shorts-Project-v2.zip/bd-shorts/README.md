# BD Shorts — starter project

Dark vertical-video social app starter using Expo React Native + Firebase.

## Setup
1. Install Node.js LTS and npm.
2. Create a Firebase project; enable Authentication > Email/Password, create Firestore, and enable Storage.
3. Copy `.env.example` to `.env` and enter the Firebase Web app config values.
4. Publish `firestore.rules` and `storage.rules` in Firebase Console.
5. Run `npm install`, then `npx expo install --fix`, then `npx expo start`.

## Build APK/AAB
Install EAS CLI: `npm install -g eas-cli`, then `eas login` and `eas build:configure`.
Create `eas.json`:
```json
{"build":{"preview":{"distribution":"internal","android":{"buildType":"apk"}},"production":{"android":{"buildType":"app-bundle"}}}}
```
Build test APK: `eas build --platform android --profile preview`
Build Play Store AAB: `eas build --platform android --profile production`

As of 31 Aug 2026, new Google Play apps must target Android 16/API 36 or higher. Check Play Console policy before submitting.

## Important
This starter is not production hardened. Before public launch, add reporting/blocking, moderation, privacy policy, terms, account deletion, upload progress, pagination, video transcoding, anti-abuse controls, and test rules. Never embed Firebase service-account private keys in the app. Firebase usage and video bandwidth may incur charges.
